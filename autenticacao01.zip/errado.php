<!DOCTYPE html>
<html>
<head>
 <style> 
   h1{
     text-align: center;
    }
    p{
     text-align: center;
    }
  </style>
  <title>Login</title>
</head>
  <div class="nav"> 
  </div>
  <div class="content">
    <div> 
      <h1>INCORRETO</h1>
     <p>Email ou senha incorretos, digite novamente</p>
    </div>
  </div>
</html>